<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Book: <?php echo e($book->title); ?>

                </div>

                <div class="panel-body">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <td>Title</td>
                                <td><?php echo e($book->title); ?></td>
                            </tr>
                            <tr>
                                <td>Author</td>
                                <td><?php echo e($book->author); ?></td>
                            </tr>
                            <tr>
                                <td>Publisher</td>
                                <td><?php echo e($book->publisher); ?></td>
                            </tr>
                            <tr>
                                <td>Year</td>
                                <td><?php echo e($book->year); ?></td>
                            </tr>
                            <tr>
                                <td>ISBN</td>
                                <td><?php echo e($book->isbn); ?></td>
                            </tr>
                            <tr>
                                <td>Price</td>
                                <td><?php echo e($book->price); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h2>Comments</h2>
                    <table class="table">
                        <thead>
                            <th>Title</th>
                            <th>Body</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $book->comments()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($comment->title); ?></th>
                                <th><?php echo e($comment->body); ?></th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                    <a href="<?php echo e(route('books.index')); ?>" class="btn btn-default">Back</a>
                    <a href="<?php echo e(route('books.edit', array('book' => $book))); ?>"
                       class="btn btn-warning">Edit</a>
                    <form style="display:inline-block" method="POST" action="<?php echo e(route('books.destroy', array('book' => $book))); ?>">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="form-control btn btn-danger">Delete</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>