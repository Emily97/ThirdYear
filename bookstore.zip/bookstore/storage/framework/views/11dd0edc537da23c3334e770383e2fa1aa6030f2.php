<?php $__env->startSection('content'); ?>

	<p>Add new book form</p>
	
	<form method="POST" action="<?php echo e(route('books.store')); ?>">
		<?php echo e(csrf_field()); ?>

		<table class="table">
			<tr>
				<td>Title</td>
				<td>
					<input type="text" 
					       name="title" 
						   id="title" 
						   value="<?php echo e(old('title')); ?>" />
				</td>
				<td>
				<?php if($errors->has('title')): ?>
					<span class="text-danger">
					<?php echo e($errors->first('title')); ?>

					</span>
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td>Author</td>
				<td>
					<input type="text" 
					       name="author" 
						   id="author" 
						   value="<?php echo e(old('author')); ?>" />
				</td>
				<td>
				<?php if($errors->has('author')): ?>
					<span class="text-danger">
					<?php echo e($errors->first('author')); ?>

					</span>
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td>Publisher</td>
				<td>
					<input type="text" 
					       name="publisher" 
						   id="publisher" 
						   value="<?php echo e(old('publisher')); ?>" />
				</td>
				<td>
				<?php if($errors->has('publisher')): ?>
					<span class="text-danger">
					<?php echo e($errors->first('publisher')); ?>

					</span>
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td>Year</td>
				<td>
					<input type="text" 
					       name="year" 
						   id="year" 
						   value="<?php echo e(old('year')); ?>" />
				</td>
				<td>
				<?php if($errors->has('year')): ?>
					<span class="text-danger">
					<?php echo e($errors->first('year')); ?>

					</span>
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td>ISBN</td>
				<td>
					<input type="text" 
					       name="isbn" 
						   id="isbn" 
						   value="<?php echo e(old('isbn')); ?>" />
				</td>
				<td>
				<?php if($errors->has('isbn')): ?>
					<span class="text-danger">
					<?php echo e($errors->first('isbn')); ?>

					</span>
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td>Price</td>
				<td>
					<input type="text" 
					       name="price" 
						   id="price" 
						   value="<?php echo e(old('price')); ?>" />
				</td>
				<td>
				<?php if($errors->has('price')): ?>
					<span class="text-danger">
					<?php echo e($errors->first('price')); ?>

					</span>
				<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<input type="submit" 
					       name="submit" 
						   id="submit" 
						   class="btn btn-primary"
						   value="Submit" />

					<a href="<?php echo e(route('books.index')); ?>" class="btn btn-link">Cancel</a>
				</td>
				<td></td>
			</tr>
		</table>
		
	</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>