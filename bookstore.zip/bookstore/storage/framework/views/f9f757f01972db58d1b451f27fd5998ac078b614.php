<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>

            <div class="panel panel-default">
                <div class="panel-heading">
                    Books

                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-link" data-toggle="modal" data-target="#modal-form">
                      Add
                    </button>
                    <!-- Modal -->
                    <div class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form method="POST" action="<?php echo e(route('books.store')); ?>">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel">Add new book</h4>
                              </div>
                              <div class="modal-body">
                                  <div class="form-group">
                                      <label for="title">Title</label>
                                      <input type="text" class="form-control" id="title" name="title" value="" />
                                      <span class="error" id="error-title"></span>
                                  </div>
                                  <div class="form-group">
                                      <label for="author">Author</label>
                                      <input type="text" class="form-control" id="author" name="author" value="" />
                                      <span class="error" id="error-author"></span>
                                  </div>
                                  <div class="form-group">
                                      <label for="publisher">Publisher</label>
                                      <input type="text" class="form-control" id="publisher" name="publisher" value="" />
                                      <span class="error" id="error-publisher"></span>
                                  </div>
                                  <div class="form-group">
                                      <label for="year">Year</label>
                                      <input type="number" class="form-control" id="year" name="year" value="" />
                                      <span class="error" id="error-year"></span>
                                  </div>
                                  <div class="form-group">
                                      <label for="isbn">ISBN</label>
                                      <input type="text" class="form-control" id="isbn" name="isbn" value="" />
                                      <span class="error" id="error-isbn"></span>
                                  </div>
                                  <div class="form-group">
                                      <label for="price">Price</label>
                                      <input type="number" class="form-control" id="price" name="price" value="" />
                                      <span class="error" id="error-price"></span>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                  <button type="button" class="btn btn-primary" id="btn-submit">Submit</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                </div>

                <div class="panel-body">
                    <?php if(count($books) === 0): ?>
                        <p>There are no books!</p>
                    <?php else: ?>
                        <table class="table table-hover">
                            <thead>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Publisher</th>
                                <th>Year</th>
                                <th>ISBN</th>
                                <th>Price</th>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($book->title); ?></td>
                                    <td><?php echo e($book->author); ?></td>
                                    <td><?php echo e($book->publisher); ?></td>
                                    <td><?php echo e($book->year); ?></td>
                                    <td><?php echo e($book->isbn); ?></td>
                                    <td><?php echo e($book->price); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('books.show', array('book' => $book))); ?>"
                                           class="btn btn-default">View</a>
                                        <a href="<?php echo e(route('books.edit', array('book' => $book))); ?>"
                                           class="btn btn-warning">Edit</a>
                                        <form style="display:inline-block" method="POST" action="<?php echo e(route('books.destroy', array('book' => $book))); ?>">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <button type="submit" class="form-control btn btn-danger">Delete</a>
                                        </form>
                                   </td>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>